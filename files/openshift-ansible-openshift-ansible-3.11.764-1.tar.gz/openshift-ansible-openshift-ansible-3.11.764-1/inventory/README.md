# OpenShift Ansible example inventory config files
