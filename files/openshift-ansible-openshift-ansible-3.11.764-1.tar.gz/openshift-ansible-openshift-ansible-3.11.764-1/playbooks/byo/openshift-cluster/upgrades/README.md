# Upgrade playbooks
The playbooks provided in this directory can be used for upgrading an existing
cluster. Additional notes for the associated upgrade playbooks are
provided in their respective directories.

# Upgrades available
- [OpenShift Container Platform 3.10 to 3.11](v3_11/README.md) (upgrade OpenShift Origin from 3.10.x to 3.11.x)
