# Updating config files

The plays in this directory are for updating existing configuration files
of various types.

These plays are not for upgrading the version of OpenShift, those plays are in
playbooks/common/openshift-cluster/upgrades/v<upgrade version>/.
